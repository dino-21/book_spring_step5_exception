package org.zerock.exception;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import lombok.extern.log4j.Log4j;

@ControllerAdvice //예외처리
@Log4j
public class CommonExceptionAdvice {
	    // 예외처리
		@ExceptionHandler(Exception.class)
		public String except(Exception e, Model modle) {
			log.error("execption : " + e.getMessage());
			modle.addAttribute("Exception", e);

			log.error(modle);
			return "error_page";

		}

}
