package org.zerock.controller;

import org.springframework.http.HttpHeaders;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.zerock.domain.SampleDTO;
import org.zerock.domain.TodoDTO;

import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/sample/*")
@Log4j
public class SampleController {


	@GetMapping("/ex18")
	public ResponseEntity<String> ex17() {

		  log.info("ex18---------------");

	        String msg = "{\"name\":\"홍길동\"}";

	        HttpHeaders headers = new HttpHeaders();

	        headers.add("Content-type", "application/json;charset=utf8");

	      //  return new ResponseEntity<String>(msg, headers, HttpStatus.OK);
	        return new ResponseEntity<String>(msg, headers, HttpStatus.ACCEPTED);
	}

	
	
	// 객체 타입 json , xml
	// Jackson 라이브러리를 이용해 클라이언트에서 전송된 JSON 데이터가
	// @RequestBody를 통해 받아지고, 해당 데이터는 SampleDTO 객체로 자동 변환된다.

	// @ResponseBody 어노테이션을 사용하면 메소드의 반환 값이 HTTP 응답의 본문으로 사용되어 클라이언트에게 전송된다.
	// POST 요청과 함께 JSON 형태의 데이터를 반환할 때 사용된다.
	// 반환값: 메소드는 "success" 문자열을 반환
	@PostMapping("/ex17")
	public @ResponseBody String ex17(@RequestBody SampleDTO dto) {
		log.info("ex17---------------");
		log.info(dto);
		return "success";
	}

	// @ResponseBody 어노테이션이 적용되어 있어서 해당 메소드의 반환 값이 직접 HTTP 응답의 본문으로 전송된다.
	// SampleDTO 객체가 만들어지고, 이 객체가 JSON 형식으로 변환되어 클라이언트에게 전송
	@GetMapping("/ex16")
	public @ResponseBody SampleDTO ex16() {
		log.info("ex16---------------");

		SampleDTO dto = new SampleDTO();
		dto.setName("kangsan");
		dto.setAge(3);

		return dto;
	}

	
	
	
	
	//반환타입 void, String
	
	@GetMapping("/testVoid")
	public void funcVoid() {
		log.info("void---------");  //return의 파일명이 없어도 jsp찾으러간다.
	} 
	
	@GetMapping("/testString")
    public String funcString() {
		log.info("string-------------");
		return "/sample/testString";
	}	
	
	@GetMapping("/ex008")
	public String ex008(Model model, SampleDTO dto, int page) {
		log.info(dto);
		log.info(page);
		 // 모델에 값 추가
	    model.addAttribute("dto", dto);
	    model.addAttribute("page", page);
		return "/sample/ex008";
	}
	
	
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		binder.registerCustomEditor(java.util.Date.class, new CustomDateEditor(dateFormat, false));
	}
	
	
	@GetMapping("/ex007")
	public String ex007(TodoDTO dto) {
		log.info("dto: " + dto);
		return "ex007";
	}
	
	
	
	@GetMapping("/ex04")
	public String ex04(@RequestParam("name") String n, @RequestParam("age") int a) {
		
		log.info("name : " + n);
		log.info("age : " + a);
		return "ex04";
	}

	
	@GetMapping("/ex03")
	public String ex03(@RequestParam("name") String name, @RequestParam("age") int age) {
		
		log.info("name : " + name);
		log.info("age : " + age);
		return "ex03";
	}

	
	@GetMapping("/ex02")
	public String ex02(String name, int age) {
		log.info("name : " + name);
		log.info("age : " + age);
		return "ex02";
	}

	@GetMapping("/ex01")
	public String ex01(SampleDTO sampleDTO) {
		log.info("ex01 : " + sampleDTO);
		return "ex01";
	}

	@RequestMapping("")
	public void basic() {
		log.info("basic------------");
	}

	@RequestMapping(value = "/basic", method = { RequestMethod.GET, RequestMethod.POST })
	public void basicGet() {
		log.info("basic get-----------------");
	}

	@GetMapping("/basicOnlyGet")
	public void basicGet2() {
		log.info("basicOnlyGet---------------");
	}

	@PostMapping("basicOnlyPost")
	public void basicPost() {
		log.info("basicOnlyPost----------------");
	}
}
